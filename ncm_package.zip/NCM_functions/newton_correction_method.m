function [x,lambda,ctr,run_time,converge] = ...
    newton_correction_method(T,max_itr,delta,x_init)
% function [x,lambda,ctr,run_time,converge] = ...
%      newton_correction_method(T,max_itr,delta,x_init)
%
% Code by Ariel Jaffe, Roi Weiss and Boaz Nadler
% 2017, Weizmann Institute of Science
% ---------------------------------------------------------
% DESCRIPTION:
% 	This function implements the Newton correction method
%   for computing real eigenpairs of symmetric tensors
%
% Input:    T - A cubic real and symmetric tensor
%           max_itr - maximum number of iterations until
%                     termination
%           delta - convergence threshold
%           x_init(opt) - initial point
%
% DEFAULT:
%   if nargin<4 x_init is chosen randomly over the unit sphere
%
% Output:   x - output eigenvector
%           ctr - number of iterations till convergence
%           run_time - time till convergence
%           convergence (1- converged)
% ---------------------------------------------------------
% FOR MORE DETAILS SEE:
%   A. Jaffe, R. Weiss and B. Nadler.
%   Newton correction methods for computing
%   real eigenpairs of symmetric tensors (2017)
% ---------------------------------------------------------
tic;

% get tensor dimensionality and order
n_vec = size(T);
m = length(n_vec);
n = n_vec(1);

% if not given as input, randomly initialize
if nargin<4
    x_init = randn(n,1);
    x_init = x_init/norm(x_init);
end

R = 1;

% init lambda_(k) and x_(k)
lambda = symmetric_tv_mode_product(T,x_init,m);
x_k = x_init;

ctr = 1;
while(R>delta && ctr<max_itr)
    
    % compute T(I,I,x_k,...,x_k), T(I,x_k,...,x_k) and g(x_k)
    T_x_m_2 = symmetric_tv_mode_product(T,x_k,m-2);
    T_x_m_1 = T_x_m_2*x_k;
    g = -lambda*x_k+T_x_m_1;
    
    % compute Hessian H(x_k)
    H = (m-1)*T_x_m_2-lambda*eye(n);
        
    %fix eigenvector
    y = -1*((H-m*x_k*T_x_m_1')^-1)*g;
    x_k_n = (x_k + y)/(norm(x_k + y));
        
    % update residual and lambda
    R = norm(x_k-x_k_n);
    x_k = x_k_n;    
    lambda = symmetric_tv_mode_product(T,x_k,m);
    
    ctr = ctr+1;
end
x = x_k;
run_time = toc;

if ctr<max_itr
    converge = 1;
else
    converge = 0;
end

end