% A script to generate figure 6 (right) from the paper
% A. Jaffe, R. Weiss and Boaz Nadler
% Newton correction methods for computing real eigenpairs of symmetric tensors (2017)

clear
addpath('./NCM_functions/');

M = 10;                        % number of tensors
m = 4;                         % mode
delta = 10^-10;                % threshold for convergence
max_restarts = 10^5;           % maximum number of random restarts per tensor
max_itr = 200;                 % maximum number of iterations until convergence
n_vec = 3:8;                   % dimensionality vector
save_results = 0;

ncm_time = zeros(M,length(n_vec));
oncm_time = zeros(M,length(n_vec));

%% 1. load M tensors for each dimensionality
for i = 1:M
    disp(i);
    for n_idx = 1:length(n_vec)
        n = n_vec(n_idx);
        
        % load tensor, with pre-calculated eigenpairs        
        load(sprintf('tensors/ten_n_%d_%d',n,i));
        l = size(X,2);
        
        % initialize results table with zeros.
        % results columns:   1. index of converged eigenpai (from 1..l)
        %                    2. number of iterations
        %                    3. time to converge
        %                    4. 1-converge,0-terminated with no convergence
        
        ncm_results = zeros(max_restarts,4);
        oncm_results = zeros(max_restarts,4);
        ncm_flag=0;
        oncm_flag = 0;
                
        % run ncm until all eigenvectors are found or reached max_restats
        t_ncm_start = datetime('now');ctr = 0;
        while  (ncm_flag==0  && ctr<max_restarts)
            
            ctr = ctr+1;            
            % run newton correction method with random init
            [v,lam,ncm_results(ctr,2),ncm_results(ctr,3),ncm_results(ctr,4)]...
                = newton_correction_method(T,max_itr,delta);
            if ncm_results(ctr,4)==1
                [~,ncm_results(ctr,1)] = max(abs(X'*v));
            end
            
            % Check if ncm converged to all eigenvectors
            if length(unique(ncm_results(ncm_results(:,4)==1,1)))==l
                ncm_flag = ctr;
            end
        end
        t_ncm_stop = datetime('now');
        t_ncm = second(datenum(t_ncm_stop-t_ncm_start));
        ncm_time(i,n_idx) = t_ncm;
        
        % run oncm until all eigenvectors are found or reached max_restats
        t_oncm_start = datetime('now');ctr = 0;
        while  (oncm_flag==0  && ctr<max_restarts)
            
            ctr = ctr+1;
            
            % run orthogonal newton correction method with predefined init            
            [v,lam,oncm_results(ctr,2),oncm_results(ctr,3),oncm_results(ctr,4)]...
                = orthogonal_newton_correction_method(T,max_itr,delta);
            if oncm_results(ctr,4)==1
                [~,oncm_results(ctr,1)] = max(abs(X'*v));
            end
            
            % Check if orthogonal method converged to all eigenvectors
            if length(unique(oncm_results(oncm_results(:,4)==1,1)))==l
                oncm_flag = ctr;
            end
        end
        t_oncm_stop = datetime('now');
        t_oncm = second(datenum(t_oncm_stop-t_oncm_start));
        oncm_time(i,n_idx) = t_oncm;
        
        % save results
        if save_results
           save(sprintf('./results/res_%d_%d.mat',n_idx,i),'ncm_results',...
               'oncm_results','t_ncm','t_oncm');
        end
    end
end

%% plot total runtime
fig = figure;
FS = 16;
%errorbar(n_vec,mean(hom_time,1),std(hom_time,1),'-sk','linewidth',2,'markerfacecolor','auto');
errorbar(n_vec,mean(ncm_time,1),std(ncm_time,1),'--ob','linewidth',2,'markerfacecolor','auto');hold on;grid on;
errorbar(n_vec,mean(oncm_time,1),std(oncm_time,1),'-.+m','linewidth',2,'markerfacecolor','auto');
%legend({'Homotopy','NCM','O-NCM'},'fontsize',FS,'location','northwest');
legend({'NCM','O-NCM'},'fontsize',FS,'location','northwest');
fig.CurrentAxes.FontSize =FS;
xlim([n_vec(1) n_vec(end)]);
%ylim([10^-2 max(mean(hom_time,1))]);
xlabel('Dimension $n$','fontsize',FS,'interpreter','latex');
ylabel('Runtime (sec)','fontsize',FS,'interpreter','latex');
fig.CurrentAxes.YScale = 'log';
ax = gca;
ax.YTick = 10.^[-2:1:4];
%grid minor;
%print(fig,'../manuscript/ver_12/figures/time_all_eigenvectors_4th_order.eps','-depsc');

